//
//  UILongPressGestureRecognizerProxy.m
//  MonkeyTalk
//
//  Created by Kyle Balogh on 5/14/13.
//  Copyright (c) 2013 Gorilla Logic, Inc. All rights reserved.
//

#import "UILongPressGestureRecognizerProxy.h"

@implementation UILongPressGestureRecognizerProxy

@end
