//
//  UIViewController+MTReady.h
//  MonkeyTalk
//
//  Created by Kyle Balogh on 10/14/13.
//  Copyright (c) 2013 Gorilla Logic, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (MTReady)

@end
