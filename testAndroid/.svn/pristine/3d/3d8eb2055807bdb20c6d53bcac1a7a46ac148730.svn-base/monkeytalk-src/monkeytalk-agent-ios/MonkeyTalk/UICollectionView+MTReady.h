//
//  UICollectionView+MTReady.h
//  MonkeyTalk
//
//  Created by gorilla logic on 12/11/13.
//  Copyright (c) 2013 Gorilla Logic, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UICollectionView (MTReady)
- (NSString *) valueForProperty:(NSString *)prop withArgs:(NSArray *)args;
@end
