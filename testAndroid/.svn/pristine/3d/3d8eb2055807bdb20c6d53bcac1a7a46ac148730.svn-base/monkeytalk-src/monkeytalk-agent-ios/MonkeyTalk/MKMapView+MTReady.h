//
//  MKMapView+MTReady.h
//  MonkeyTalk
//
//  Created by Kyle Balogh on 11/30/12.
//  Copyright (c) 2012 Gorilla Logic, Inc. All rights reserved.
//

#import <MapKit/MapKit.h>

@interface MKMapView (MTReady)

@end
