#import <Foundation/Foundation.h>
#import "MTHTTPResponse.h"


@interface MTHTTPDataResponse : NSObject <MTHTTPResponse>
{
	NSUInteger offset;
	NSData *data;
}

- (id)initWithData:(NSData *)data;

@end
