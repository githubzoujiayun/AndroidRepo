//
//  MTWebTouchEventsGestureRecognizer.m
//  MonkeyTalk
//
//  Created by Kyle Balogh on 3/21/13.
//  Copyright (c) 2013 Gorilla Logic, Inc. All rights reserved.
//

#import "MTWebTouchEventsGestureRecognizer.h"

@implementation UIWebTouchEventsGestureRecognizer
@end

@implementation MTWebTouchEventsGestureRecognizer

@end
