//
//  MTHTTPVirtualDirectory+Remove.h
//  iWebDriver
//
//  Created by Yu Chen on 6/1/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//
#import <Foundation/Foundation.h>
#import "MTHTTPVirtualDirectory.h"

@class MTWebViewController;

@interface MTHTTPVirtualDirectory (Remove)
- (void) removeChildren;
@end
