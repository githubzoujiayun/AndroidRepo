//
//  UITapGestureRecognizer+MTReady.h
//  MonkeyTalk
//
//  Created by Kyle Balogh on 3/21/13.
//  Copyright (c) 2013 Gorilla Logic, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MTWebTouchEventsGestureRecognizer.h"

@interface UITapGestureRecognizer (MTReady)

@end
