#import "MTDDRange.h"
#import "MTDDNumber.h"

MTDDRange MTDDUnionRange(MTDDRange range1, MTDDRange range2)
{
	MTDDRange result;
	
	result.location = MIN(range1.location, range2.location);
	result.length   = MAX(DDMaxRange(range1), DDMaxRange(range2)) - result.location;
	
	return result;
}

MTDDRange MTDDIntersectionRange(MTDDRange range1, MTDDRange range2)
{
	MTDDRange result;
	
	if((DDMaxRange(range1) < range2.location) || (DDMaxRange(range2) < range1.location))
	{
		return DDMakeRange(0, 0);
	}
	
	result.location = MAX(range1.location, range2.location);
	result.length   = MIN(DDMaxRange(range1), DDMaxRange(range2)) - result.location;
	
	return result;
}

NSString *MTDDStringFromRange(MTDDRange range)
{
	return [NSString stringWithFormat:@"{%qu, %qu}", range.location, range.length];
}

MTDDRange MTDDRangeFromString(NSString *aString)
{
	MTDDRange result = DDMakeRange(0, 0);
	
	// NSRange will ignore '-' characters, but not '+' characters
	NSCharacterSet *cset = [NSCharacterSet characterSetWithCharactersInString:@"+0123456789"];
	
	NSScanner *scanner = [NSScanner scannerWithString:aString];
	[scanner setCharactersToBeSkipped:[cset invertedSet]];
	
	NSString *str1 = nil;
	NSString *str2 = nil;
	
	BOOL found1 = [scanner scanCharactersFromSet:cset intoString:&str1];
	BOOL found2 = [scanner scanCharactersFromSet:cset intoString:&str2];
	
	if(found1) [NSNumber parseString:str1 intoUInt64:&result.location];
	if(found2) [NSNumber parseString:str2 intoUInt64:&result.length];
	
	return result;
}

NSInteger MTDDRangeCompare(DDRangePointer pDDRange1, DDRangePointer pDDRange2)
{
	// Comparison basis:
	// Which range would you encouter first if you started at zero, and began walking towards infinity.
	// If you encouter both ranges at the same time, which range would end first.
	
	if(pDDRange1->location < pDDRange2->location)
	{
		return NSOrderedAscending;
	}
	if(pDDRange1->location > pDDRange2->location)
	{
		return NSOrderedDescending;
	}
	if(pDDRange1->length < pDDRange2->length)
	{
		return NSOrderedAscending;
	}
	if(pDDRange1->length > pDDRange2->length)
	{
		return NSOrderedDescending;
	}
	
	return NSOrderedSame;
}

@implementation NSValue (NSValueDDRangeExtensions)

+ (NSValue *)valueWithDDRange:(MTDDRange)range
{
	return [NSValue valueWithBytes:&range objCType:@encode(MTDDRange)];
}

- (MTDDRange)ddrangeValue
{
	MTDDRange result;
	[self getValue:&result];
	return result;
}

- (NSInteger)ddrangeCompare:(NSValue *)other
{
	MTDDRange r1 = [self ddrangeValue];
	MTDDRange r2 = [other ddrangeValue];
	
	return MTDDRangeCompare(&r1, &r2);
}

@end
