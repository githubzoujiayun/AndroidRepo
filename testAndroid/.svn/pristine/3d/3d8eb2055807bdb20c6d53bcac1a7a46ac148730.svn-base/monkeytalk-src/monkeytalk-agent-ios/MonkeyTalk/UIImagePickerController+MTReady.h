//
//  UIImagePickerController+MTReady.h
//  MonkeyTalk
//
//  Created by Kyle Balogh on 12/7/12.
//  Copyright (c) 2012 Gorilla Logic, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImagePickerController (MTReady)
+ (void) playbackMonkeyEvent:(id)event;
@end
