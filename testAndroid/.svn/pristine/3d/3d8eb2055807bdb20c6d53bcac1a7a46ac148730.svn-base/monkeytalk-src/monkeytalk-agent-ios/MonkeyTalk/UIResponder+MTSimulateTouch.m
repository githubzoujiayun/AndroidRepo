//
//  UIResponder+MTSimulateTouch.m
//  iWebDriver
//
//  Created by Joseph Gentle on 1/22/09.
//  Copyright 2009 Google Inc. All rights reserved.
//

#import "UIResponder+MTSimulateTouch.h"


@implementation UIResponder (MTSimulateTouch)

// TODO: Complete me.
- (void)simulateTapAt:(CGPoint)point {
  
}

@end
