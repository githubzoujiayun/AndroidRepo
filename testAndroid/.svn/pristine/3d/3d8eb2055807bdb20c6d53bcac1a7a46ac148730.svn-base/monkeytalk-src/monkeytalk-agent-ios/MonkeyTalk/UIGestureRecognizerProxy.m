//
//  UIGestureRecognizerProxy.m
//  MonkeyTalk
//
//  Created by Kyle Balogh on 2/8/12.
//  Copyright 2012 Gorilla Logic, Inc. All rights reserved.
//

#import "UIGestureRecognizerProxy.h"


@implementation UIGestureRecognizerProxy

@end
