//
//  UIGestureRecognizerTargetProxy.m
//  MonkeyTalk
//
//  Created by Kyle Balogh on 2/10/12.
//  Copyright 2012 Gorilla Logic, Inc. All rights reserved.
//

#import "UIGestureRecognizerTargetProxy.h"


@implementation UIGestureRecognizerTargetProxy

@end
