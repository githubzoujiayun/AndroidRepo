//
//  UILongPressGestureRecognizerProxy.h
//  MonkeyTalk
//
//  Created by Kyle Balogh on 5/14/13.
//  Copyright (c) 2013 Gorilla Logic, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <UIKit/UIGestureRecognizerSubclass.h>

@interface UILongPressGestureRecognizerProxy : UILongPressGestureRecognizer

@end
