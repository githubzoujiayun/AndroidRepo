now building all projects fine using Indigo Java plus SVN, ADT, AJDT, PDE

Indigo Java - comes with m2e (maven)
  - subclipse (svn)
  - ADT (Android)
  - AJDT (Aspect-J)
  - PDE (plug-in-development)
  - JSDT (JavaScript Development Tools)

Indigo J2EE
  - m2e
  - subclipse
  - ADT
  - AJDT
  - PDE

Juno? who knows?