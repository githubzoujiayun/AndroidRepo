package com.gorillalogic.fonemonkey.automators;

public class HtmlButtonSelectorAutomator extends HtmlRadioButtonAutomator {
	@Override
	public String getComponentType() {
		return "ButtonSelector";
	}
}
