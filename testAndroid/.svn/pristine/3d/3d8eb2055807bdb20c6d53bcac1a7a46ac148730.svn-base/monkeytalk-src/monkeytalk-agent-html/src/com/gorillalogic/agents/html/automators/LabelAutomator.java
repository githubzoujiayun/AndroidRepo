package com.gorillalogic.agents.html.automators;

public class LabelAutomator extends WebElementAutomator {
	public static String componentType = "Label";
	public static String[] aliases = { "DIV" };
}
