package com.gorillalogic.agents.html.browser;

public class FirefoxAdapter extends BrowserAdapter {
	
	public BrowserType getBrowserType() {
		return BrowserType.FIREFOX;
	}

	public String getPath() {
		return "Not needed";
	}
			
}
