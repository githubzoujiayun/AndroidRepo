===============================================================================
ROBOTIUM
===============================================================================

Robotium is an Android test framework that has full support for WebViews, Activities, Dialogs, Toasts, Menus and Context Menus. 

The project home page is at http://www.robotium.org/


